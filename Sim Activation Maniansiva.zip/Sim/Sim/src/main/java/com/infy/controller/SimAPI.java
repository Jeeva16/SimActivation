package com.infy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.SimOffers;
import com.infy.service.SimService;

@RestController
@Validated
@RequestMapping("/SimDetails")
public class SimAPI {
	
	@Autowired
	SimService service= null;
	
	@PostMapping(value="/{serviceNumber}/{simNumber}")
	public SimOffers simDetails(@PathVariable("serviceNumber") @Pattern(regexp = "[0-9]{10}",message="InvalidService")String serviceNumber,
			@PathVariable("simNumber") @Pattern(regexp = "[0-9]{13}",message="Invalid sim number")String simNumber) {
			
		Long serviceNum=Long.parseLong(serviceNumber);
		Long simNum=Long.parseLong(simNumber);
		
		List<SimOffers> cus = service.getsimOffers(simNum, serviceNum);
		if(!cus.isEmpty()) {
			for(SimOffers simoffer : cus) {
				return simoffer;
			}
		}
		else
			return null;
	}
	
	@GetMapping(value="/update/{simId}")
	public Integer update(@PathVariable Integer simId) {
		return service.updatesimStatus(simId);
	}

}
