package com.infy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.infy.model.SimOffers;
import com.infy.repo.SimRepository;

@Service
public class SimService {
	
	SimRepository repository;
	
	public List<SimOffers> getsimOffers(Long simNumber,Long serviceNumber){
		List<SimOffers> simOffer;
		simOffer=repository.findbysimId(simNumber, serviceNumber);
		return simOffer;
	}
	
	public Integer updatesimStatus(Integer simId) {
		return repository.updateId(simId);
	}

}
