package com.infy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.model.SimOffers;

@Repository
public interface SimRepository extends JpaRepository<SimOffers, Integer>{
	
	List<SimOffers> findbysimId(Long simNumber,Long serviceNumber);
	
	
	Integer updateId(Integer simId);

}
