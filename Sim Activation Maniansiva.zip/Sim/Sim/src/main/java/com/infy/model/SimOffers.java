package com.infy.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SimOffers {
	
	@Id
	private Integer offerId;
	private Integer callQty;
	private Integer cost;
	private Integer dataQty;
	private String offerName;
	private Integer simId;
	public SimOffers(Integer offerId, Integer callQty, Integer cost, Integer dataQty, String offerName, Integer simId) {
		super();
		this.offerId = offerId;
		this.callQty = callQty;
		this.cost = cost;
		this.dataQty = dataQty;
		this.offerName = offerName;
		this.simId = simId;
	}
	public Integer getOfferId() {
		return offerId;
	}
	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}
	public Integer getCallQty() {
		return callQty;
	}
	public void setCallQty(Integer callQty) {
		this.callQty = callQty;
	}
	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	public Integer getDataQty() {
		return dataQty;
	}
	public void setDataQty(Integer dataQty) {
		this.dataQty = dataQty;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	public Integer getSimId() {
		return simId;
	}
	public void setSimId(Integer simId) {
		this.simId = simId;
	}
	
	
	

}
