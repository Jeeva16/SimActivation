package com.infy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.model.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>{
	
	List<Customer> findByDobandEmail(String dob,String email);
	
	List<Customer> findByNameandEmail(String firstName,String lastName,String email);
	
	Integer updateId(Long cid,String firstName,String lastName,String dob);

}
