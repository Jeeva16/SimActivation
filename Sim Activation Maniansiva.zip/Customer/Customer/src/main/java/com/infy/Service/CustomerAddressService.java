package com.infy.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.repo.CustomerAddressRepository;

@Service
public class CustomerAddressService {
	
	@Autowired
	CustomerAddressRepository customerAddressRepository;
	
	public Integer updateAddress(Integer  addressId,String address,String city,Long pincode,String state) {
		return customerAddressRepository.addressUpdate(addressId, address, city, pincode, state);
	}

}
