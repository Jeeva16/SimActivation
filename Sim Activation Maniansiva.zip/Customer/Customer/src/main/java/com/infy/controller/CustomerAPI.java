package com.infy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.Service.CustomerAddressService;
import com.infy.Service.CustomerService;
import com.infy.dto.CustomerDTO;

@RestController
@Validated
@RequestMapping("/CustomerDetails")
public class CustomerAPI {
	
	@Autowired
	CustomerService service=null;
	@Autowired
	CustomerAddressService service2=null;
	@Autowired
	RestTemplate template;
	
	@PostMapping(value="/{firstName}/{lastName}/{email}")
	public String customerDetails(@PathVariable("dob") @Pattern(regexp="[0-9]{4}-[0-9]{2}-[0-9]{2}",message="Invalid DOB") String dob,
			@PathVariable("email") @Pattern(regexp="^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",message="Invalid Email") String email) {
		List<CustomerDTO> cus =service.getDobAndEmail(dob, email);
		if(!cus.isEmpty()) {
			for(CustomerDTO cust :cus) {
				return "Succesfully validated";
			}
		}
		else
			return "No request placed for you";
	}
	


}