package com.infy.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.CustomerDTO;
import com.infy.model.Customer;
import com.infy.repo.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public List<CustomerDTO> getDobAndEmail(String dob,String email){
		List<CustomerDTO> cus = new ArrayList<>();
		
		List<Customer> customer = customerRepository.findByDobandEmail(dob, email);
		for(Customer cust : customer) {
			cus.add(CustomerDTO.valueOf(cust));
			
		}
		if(!customer.isEmpty())
			for(CustomerDTO cust :cus)
				System.out.println("Customer found : " +cust);
				return cus;
	}
	
	public List<CustomerDTO> getNameandEmail(String firstName,String lastName,String email){
		List<CustomerDTO> cus = new ArrayList<>();
		for(Customer cust:customerRepository.findByNameandEmail(firstName, lastName, email)) {
			cus.add(CustomerDTO.valueOf(cust));
		}
		return cus;
	}
	
	public Integer updatesimStatus(Long uid,String firstName,String lastName,String dob) {
		return customerRepository.updateId(uid, firstName, lastName, dob);
	}

}
