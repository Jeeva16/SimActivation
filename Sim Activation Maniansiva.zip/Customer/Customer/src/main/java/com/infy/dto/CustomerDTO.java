package com.infy.dto;

import com.infy.model.Customer;

public class CustomerDTO {

	 Long id;
	 String dob;
	 String email;
	 String firstName;
	 String lastName;
	 String idType;
     Integer addressId;
     String state;
     
     SimDTO simDetails;
     public CustomerDTO() {
    	 super();
     }

 	public CustomerDTO(Long id, String dob, String email, String firstName, String lastName, String idType,
 			Integer addressId, String state, SimDTO simDetails) {
 		super();
 		this.id = id;
 		this.dob = dob;
 		this.email = email;
 		this.firstName = firstName;
 		this.lastName = lastName;
 		this.idType = idType;
 		this.addressId = addressId;
 		this.state = state;
 		this.simDetails = simDetails;
 	}
     
	 public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public SimDTO getSimDetails() {
		return simDetails;
	}

	public void setSimDetails(SimDTO simDetails) {
		this.simDetails = simDetails;
	}

	

	
	public static CustomerDTO valueOf(Customer cust) {
		CustomerDTO custDTO = new CustomerDTO();
		
		custDTO.setId(cust.getId());
		custDTO.setDob(cust.getDob());
		custDTO.setEmail(cust.getEmail());
		custDTO.setFirstName(cust.getFirstName());
		custDTO.setLastName(cust.getLastName());
		custDTO.setIdType(cust.getIdType());
		custDTO.setAddressId(cust.getAddressId());
		custDTO.setState(cust.getState());
		
		SimDTO simDTO = new SimDTO();
		simDTO.setSimId(cust.getSimId());
		custDTO.setSimDetails(simDTO);
		
		
		
		return custDTO;
	}
}
